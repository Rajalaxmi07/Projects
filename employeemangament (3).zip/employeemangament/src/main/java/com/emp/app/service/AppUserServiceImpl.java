package com.emp.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emp.app.dto.SigninRequest;
import com.emp.app.model.AppUsers;
import com.emp.app.repository.AppUserRepository;
@Service

public class AppUserServiceImpl implements AppUserService {
 @Autowired
 private AppUserRepository appUserRepository;
 
	
	@Override
	public String saveUser(AppUsers appUser)  {
	appUserRepository.save(appUser);
		return "saved successfully";
	}

	@Override
	public List<AppUsers> getUsers() {
		// TODO Auto-generated method stub
		return appUserRepository.findAll();
	}
	@Override
	public String loginUser(SigninRequest signinRequest) {

	    AppUsers user = appUserRepository.findByEmail(signinRequest.getEmail());

	    if (user != null &&
	        user.getPassword().equals(signinRequest.getPassword())) {

	        return "Login successful";
	    }

	    return "Invalid email or password";
	}
}
