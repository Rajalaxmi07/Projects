 package com.emp.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.emp.app.model.Client;
import com.emp.app.repository.ClientRepository;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api/clients")
public class ClientController {

    @Autowired
    private ClientRepository clientRepository;

    // Get all clients
    @GetMapping
    public List<Client> getAllClients() {
        return clientRepository.findAll();
    }

    // Add a client
    @PostMapping
    public Client addClient(@RequestBody Client client) {
        client.setId(null);
        return clientRepository.save(client);
    }

    // Update a client
    @PutMapping("/{id}")
    public ResponseEntity<Client> updateClient(
            @PathVariable Long id,
            @RequestBody Client updatedClient) {

        return clientRepository.findById(id)
                .map(client -> {
                    client.setCompanyName(updatedClient.getCompanyName());
                    client.setLocation(updatedClient.getLocation());
                    client.setIndustry(updatedClient.getIndustry());
                    client.setEmail(updatedClient.getEmail());
                    client.setWebsite(updatedClient.getWebsite());

                    return ResponseEntity.ok(
                            clientRepository.save(client));
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Delete a client
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteClient(@PathVariable Long id) {

        if (!clientRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }

        clientRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}