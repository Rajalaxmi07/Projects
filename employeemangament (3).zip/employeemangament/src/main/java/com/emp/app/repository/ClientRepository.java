 package com.emp.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.emp.app.model.Client;

public interface ClientRepository extends JpaRepository<Client, Long> {

}