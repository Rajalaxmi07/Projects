 
package com.emp.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.emp.app.model.AppUsers;

public interface AppUserRepository extends JpaRepository<AppUsers, Long> {

    AppUsers findByEmail(String email);

}
