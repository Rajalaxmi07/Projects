package com.emp.app.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class RootController {
	@GetMapping("/info")
	
public String getInfo() {
	return "API running";
}
	@GetMapping("/users")
	public String[] getUsers() {
		String[] names= {"Raji","Sneha"};
		return names;
}
	@GetMapping("/id")
	 public int[] getId() {
		int[] empid= {01,02};
		return empid;
}
	
	
	
}