 package com.emp.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.emp.app.dto.SigninRequest;
import com.emp.app.model.AppUsers;
import com.emp.app.model.LoginRequest;
import com.emp.app.repository.AppUserRepository;
import com.emp.app.service.AppUserService;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/api")
public class AppUserController {

    @Autowired
    private AppUserService appUserService;

    @Autowired
    private AppUserRepository appUserRepository;

    // Register a user
    @PostMapping("/auth/register")
    public String registerUser(@RequestBody SigninRequest user) {
    	AppUsers appusers= new AppUsers(0, user.getName(), user.getEmail(), user.getPassword());
        return appUserService.saveUser(appusers);
    }

    // Login
    @PostMapping("/auth/login")
    public String loginUser(
            @RequestBody SigninRequest request) {
        return appUserService.loginUser(request);
    }

    // Display all users
    @GetMapping("/users")
    public List<AppUsers> getUsers() {
        return appUserService.getUsers();
    }

    // Add a user
    @PostMapping("/users")
    public String createUser(@RequestBody SigninRequest user) {
    	AppUsers appusers= new AppUsers(0, user.getName(), user.getEmail(), user.getPassword());
        return appUserService.saveUser(appusers);
    }

    // Update a user
    @PutMapping("/users/{id}")
    public ResponseEntity<AppUsers> updateUser(
            @PathVariable Long id,
            @RequestBody LoginRequest updatedUser) {

        return appUserRepository.findById(id)
                .map(user -> {
                    user.setName(updatedUser.getName());
                    user.setEmail(updatedUser.getEmail());

                    if (updatedUser.getPassword() != null
                            && !updatedUser.getPassword().isBlank()) {
                        user.setPassword(updatedUser.getPassword());
                    }
                    AppUsers appusers = new AppUsers(id, user.getName(), user.getEmail(), user.getPassword());

                    AppUsers savedUser =
                            appUserRepository.save(appusers);

                    return ResponseEntity.ok(savedUser);
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Delete a user
    @DeleteMapping("/users/{id}")
    public ResponseEntity<Void> deleteUser(
            @PathVariable Long id) {

        if (!appUserRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }

        appUserRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
 //  

}