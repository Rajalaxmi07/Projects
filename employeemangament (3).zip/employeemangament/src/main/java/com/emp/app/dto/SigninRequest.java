package com.emp.app.dto;

public class SigninRequest {
	private String name;
	private String email;
	private String password;
	public SigninRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SigninRequest(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	

}
