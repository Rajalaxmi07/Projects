package com.emp.app.service;

import java.util.List;

import com.emp.app.dto.SigninRequest;
import com.emp.app.model.AppUsers;

public interface AppUserService {
 public String saveUser(AppUsers appUser);
 public List<AppUsers> getUsers();
 public  String loginUser(SigninRequest signinRequest);

}
