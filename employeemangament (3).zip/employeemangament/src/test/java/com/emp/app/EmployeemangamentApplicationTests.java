package com.emp.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeemangamentApplicationTests {

	@Test
	void contextLoads() {
	}

}
